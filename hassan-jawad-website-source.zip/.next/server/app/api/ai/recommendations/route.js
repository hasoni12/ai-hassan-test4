(()=>{var e={};e.id=441,e.ids=[441],e.modules={455:(e,r,t)=>{"use strict";t.d(r,{AT:()=>o,Fq:()=>n,Zv:()=>a});let s=new(t(9905)).z4({apiKey:process.env.OPENAI_API_KEY||"your-api-key",dangerouslyAllowBrowser:!0});async function o(e,r="gpt-3.5-turbo"){try{return(await s.chat.completions.create({model:r,messages:e,temperature:.7,max_tokens:1e3})).choices[0].message.content||"عذراً، لم أستطع الإجابة على سؤالك."}catch(e){return console.error("خطأ في الاتصال بـ OpenAI:",e),"حدث خطأ أثناء معالجة طلبك. يرجى المحاولة مرة أخرى لاحقاً."}}async function n(e,r){let t=`
    أنت مساعد متخصص في توصية الدورات التعليمية للمهندسين. 
    الرجاء تقديم 3-5 توصيات لدورات تعليمية مناسبة لمهندس مهتم بالمجالات التالية: ${e.join(", ")}.
    مستوى المهندس: ${r}.
    قدم النتائج بتنسيق JSON كالتالي:
    [
      {
        "title": "عنوان الدورة",
        "description": "وصف مختصر للدورة",
        "level": "مستوى الدورة (مبتدئ/متوسط/متقدم)",
        "category": "تصنيف الدورة"
      }
    ]
  `;try{let e=(await s.chat.completions.create({model:"gpt-3.5-turbo",messages:[{role:"user",content:t}],temperature:.7,max_tokens:1e3})).choices[0].message.content||"[]";try{return JSON.parse(e),e}catch(r){return e}}catch(e){return console.error("خطأ في الحصول على توصيات الدورات:",e),"[]"}}async function a(e,r,t,o){let n=`
    أنت مستشار مهني متخصص في مجال الهندسة. 
    الرجاء إنشاء خطة مسار مهني مخصصة لمهندس بالمواصفات التالية:
    - التخصص: ${e}
    - مستوى الخبرة: ${r}
    - المهارات الحالية: ${t.join(", ")}
    - الأهداف المهنية: ${o.join(", ")}
    
    قدم خطة مفصلة تتضمن:
    1. المهارات التي يجب تطويرها
    2. الدورات والشهادات المقترحة
    3. خطوات التطور المهني على مدى 1-3 سنوات
    4. نصائح للتميز في مجال التخصص
    
    قدم النتائج بتنسيق JSON كالتالي:
    {
      "skills_to_develop": ["مهارة 1", "مهارة 2", ...],
      "recommended_courses": ["دورة 1", "دورة 2", ...],
      "certifications": ["شهادة 1", "شهادة 2", ...],
      "career_steps": ["خطوة 1", "خطوة 2", ...],
      "tips": ["نصيحة 1", "نصيحة 2", ...]
    }
  `;try{let e=(await s.chat.completions.create({model:"gpt-3.5-turbo",messages:[{role:"user",content:n}],temperature:.7,max_tokens:1500})).choices[0].message.content||"{}";try{return JSON.parse(e),e}catch(r){return e}}catch(e){return console.error("خطأ في توليد خطة المسار المهني:",e),"{}"}}},829:(e,r,t)=>{"use strict";t.r(r),t.d(r,{patchFetch:()=>x,routeModule:()=>p,serverHooks:()=>m,workAsyncStorage:()=>l,workUnitAsyncStorage:()=>d});var s={};t.r(s),t.d(s,{POST:()=>c});var o=t(6559),n=t(8088),a=t(7719),i=t(2190),u=t(455);async function c(e){try{let{interests:r,level:t,type:s}=await e.json();if(!r||!Array.isArray(r)||0===r.length)return i.NextResponse.json({error:"يجب توفير مصفوفة من الاهتمامات"},{status:400});if(!t)return i.NextResponse.json({error:"يجب تحديد المستوى"},{status:400});let o=await (0,u.Fq)(r,t);try{let e=JSON.parse(o);return i.NextResponse.json({recommendations:e})}catch(e){return i.NextResponse.json({error:"تعذر تحليل النتيجة",rawResponse:o},{status:500})}}catch(e){return console.error("خطأ في معالجة طلب التوصيات:",e),i.NextResponse.json({error:"حدث خطأ أثناء معالجة طلبك"},{status:500})}}let p=new o.AppRouteRouteModule({definition:{kind:n.RouteKind.APP_ROUTE,page:"/api/ai/recommendations/route",pathname:"/api/ai/recommendations",filename:"route",bundlePath:"app/api/ai/recommendations/route"},resolvedPagePath:"/home/ubuntu/hassan-jawad-website/src/app/api/ai/recommendations/route.ts",nextConfigOutput:"",userland:s}),{workAsyncStorage:l,workUnitAsyncStorage:d,serverHooks:m}=p;function x(){return(0,a.patchFetch)({workAsyncStorage:l,workUnitAsyncStorage:d})}},846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},1630:e=>{"use strict";e.exports=require("http")},1997:e=>{"use strict";e.exports=require("punycode")},3024:e=>{"use strict";e.exports=require("node:fs")},3033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},3566:e=>{"use strict";e.exports=require("worker_threads")},3873:e=>{"use strict";e.exports=require("path")},4075:e=>{"use strict";e.exports=require("zlib")},4870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},5591:e=>{"use strict";e.exports=require("https")},6487:()=>{},7075:e=>{"use strict";e.exports=require("node:stream")},7830:e=>{"use strict";e.exports=require("node:stream/web")},7910:e=>{"use strict";e.exports=require("stream")},8335:()=>{},8354:e=>{"use strict";e.exports=require("util")},9021:e=>{"use strict";e.exports=require("fs")},9294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},9551:e=>{"use strict";e.exports=require("url")}};var r=require("../../../../webpack-runtime.js");r.C(e);var t=e=>r(r.s=e),s=r.X(0,[447,580,905],()=>t(829));module.exports=s})();